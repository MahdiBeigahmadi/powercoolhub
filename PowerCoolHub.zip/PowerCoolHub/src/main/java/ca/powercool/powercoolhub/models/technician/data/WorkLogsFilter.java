package ca.powercool.powercoolhub.models.technician.data;

public class WorkLogsFilter {
    public static String BY_WEEK = "weekly";
    public static String BY_MONTH = "monthly";
    public static String BY_YEAR = "yearly";
}
