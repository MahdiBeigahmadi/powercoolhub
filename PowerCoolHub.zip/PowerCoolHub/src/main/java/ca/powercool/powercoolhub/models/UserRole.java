package ca.powercool.powercoolhub.models;

public class UserRole {
    public static final String TECHNICIAN = "technician";
    public static final String MANAGER = "manager";
}
